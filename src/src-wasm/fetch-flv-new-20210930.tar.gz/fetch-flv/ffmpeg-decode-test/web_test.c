//
// Created by 小老虎 on 2020/10/11.
//
#include "web_test.h"

SniffStreamContext *rdIsDad(const char *token) {
    //if (STRCMP(token, TOKEN_SECRET) != 0) {
    //    printf("t:%s\n", token);
    //    printf("t:%s\n", TOKEN_SECRET);
    //    printf("initMissileHttp start FAILED, TOKEN ERROR\n");
    //    return NULL;
    //}
    if (STRCMP(token, TOKEN_FREE) != 0) {
        printf("t:%s\n", token);
        printf("t:%s\n", TOKEN_SECRET);
        printf("initMissileHttp start FAILED, TOKEN ERROR\n");
        return NULL;
    }
    printf("initMissileHttp start OK\n");

    SniffStreamContext *sniffStreamContext = newSniffStreamContext();
    return sniffStreamContext;
}

int release(SniffStreamContext *sniffStreamContext) {
    int exitRet = releaseSniffStreamContext(sniffStreamContext);
    printf("VideoMissileHttp exit done:%d\n", exitRet);
    return exitRet;
}

int initializeModule(
        SniffStreamContext *sniffStreamContext,
        long (*probeCallback)(void), long (*yuvCallback)(void), long (*naluCallback)(void),
        long (*pcmCallback)(void), long (*aacCallback)(void)) {
    int initRet = sniffStreamContext->initFunc(sniffStreamContext, MISSILE_SNIFFSTREAM_MODE_VOD);
    sniffStreamContext->setCodecTypeFunc(
            sniffStreamContext,
            probeCallback, yuvCallback, naluCallback,
            pcmCallback, aacCallback, 0);
    return initRet;
}

int pushData(SniffStreamContext *sniffStreamContext, uint8_t *buff, int in_len, int probe_size) {
    int pushRet = sniffStreamContext->pushBufferFunc(sniffStreamContext, buff, in_len, probe_size);
    return pushRet;
}

int getPkg(SniffStreamContext *sniffStreamContext) {
    int getRet = sniffStreamContext->getPacketFunc(sniffStreamContext, 1);
    return getRet;
}

int decodeFrame(SniffStreamContext *sniffStreamContext, uint8_t *buff, uint64_t len, long pts, long dts) {
    int getRet = sniffStreamContext->decodeVideoFrameFunc(sniffStreamContext, buff, len, pts, dts, 0);
    return getRet;
}
