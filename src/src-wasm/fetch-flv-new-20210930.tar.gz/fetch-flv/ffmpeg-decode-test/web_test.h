//
// Created by 小老虎 on 2020/10/11.
//
// for wasm test entry
//

#ifndef FFMPEG_QUQI_ANALYZER_HTTP_DEMUXER_WEB_TEST_H
#define FFMPEG_QUQI_ANALYZER_HTTP_DEMUXER_WEB_TEST_H

#include "utils/secret.h"
#include "utils/tools.h"
#include "sniff_httpflv.h"

SniffStreamContext *rdIsDad(const char *token);

int release(SniffStreamContext *sniffStreamContext);

int initializeModule(
        SniffStreamContext *sniffStreamContext,
        long (*probeCallback)(void), long (*yuvCallback)(void), long (*naluCallback)(void),
        long (*pcmCallback)(void), long (*aacCallback)(void));

/**
 *
 * @param sniffStreamContext
 * @param buff
 * @param in_len
 * @param probe_size probe size
 * @return
 */
int pushData(SniffStreamContext *sniffStreamContext, uint8_t *buff, int in_len, int probe_size);

// @TODO
int getPkg(SniffStreamContext *sniffStreamContext);

int decodeFrame(SniffStreamContext *sniffStreamContext, uint8_t *buff, uint64_t len, long pts, long dts);


#endif //FFMPEG_QUQI_ANALYZER_HTTP_DEMUXER_WEB_TEST_H

