//
// Created by 小老虎 on 2020/10/18.
//

#include <stdio.h>
#include <stdlib.h>
#include "web_test.h"
#include "utils/tools.h"

//#define VIDEO_SOURCE "/Users/changyanlong01/Documents/VIDEOS/dash/test_hevc.m4s"
//#define VIDEO_SOURCE "/Users/changyanlong01/Documents/VIDEOS/livestream.flv"
#define VIDEO_SOURCE "/Users/changyanlong01/Documents/VIDEOS/fetch-flv/test.flv"

#define BUF_SIZE 4096 * 500
#define PUSH_UNIT 1
#define PUSH_SIZE 10000

FILE *g_test_f_yuv = NULL;
FILE *g_test_f_hevc = NULL;
FILE *g_test_f_pcm = NULL;
FILE *g_test_f_aac = NULL;

int g_test_f_yuv_count = 0;
int g_test_f_hevc_count = 0;
int g_test_f_pcm_count = 0;
int g_test_f_aac_count = 0;
//FILE *g_test_w_265_f = NULL;

//void callback(unsigned char* naluData, int len, int width, int height, double pts) {
//    printf("StreamCallback -> pts: %f\n", pts);
//    //fwrite(naluData, sizeof(unsigned char), len, g_test_w_265_f);
//}

SniffStreamContext *sniffStreamContext = NULL;

void probeFinCallback(double duration, uint32_t width, uint32_t height, double fps,
                      uint32_t audioIdx,
                      uint32_t sample_rate, uint32_t channels, const char* sample_fmt) {
    printf("=============> probeFinCallback \n");
    printf("=============>     VIDEO duration:%f width:%d height:%d fps:%f \n", duration, width, height, fps);
    printf("=============>     AUDIO sample_rate:%d channels:%d idx:%d\n", sample_rate, channels, audioIdx);
}

void naluFrameCallback(
        unsigned char* data, int len, int isKey,
        int width, int height, double pts, double dts) {
    decodeFrame(sniffStreamContext, data, len, (long)(pts * 1000), (long)(dts * 1000));

    printf("is key %f %d\n", pts, isKey);

    //if (g_test_f_hevc_count < 1400) {
        fwrite(data, 1, len, g_test_f_hevc);
    //} else {
        //fclose(g_test_f_hevc);
    //}
}

/**
 *
 * @param data_y
 * @param data_u
 * @param data_v
 * @param line1
 * @param line2
 * @param line3
 * @param width
 * @param height
 * @param pts
 */
void frameCallback(
        unsigned char* data_y, unsigned char* data_u, unsigned char* data_v,
        int line1, int line2, int line3, int width,
        int height, double pts) {
    //if (g_test_f_yuv_count < 100) {
        printf("frameCallback %dx%d\n", line1, height);
        fwrite(data_y, 1, line1 * height, g_test_f_yuv);
        fwrite(data_u, 1, line2 * height / 2, g_test_f_yuv);
        fwrite(data_v, 1, line3 * height / 2, g_test_f_yuv);
        g_test_f_yuv_count += 1;
    //} else {
        //fclose(g_test_f_yuv);
    //}
}

/**
 *
 * @param buffer
 * @param line1
 * @param channel
 * @param pts
 */
void samplesCallback(
        unsigned char* buffer, int line1, int channel, double pts) {
    if (g_test_f_pcm_count < 200) {
        printf("samplesCallback %d %d %f", line1, channel, pts);
        //fwrite(buffer, 1, line1, g_test_f_pcm);
        g_test_f_pcm_count += 1;
    } else {
        fclose(g_test_f_pcm);
    }
}

void aacSamplesCallback (
        unsigned char* adts, unsigned char* buffer, int line1, int channel, double pts) {
    if (g_test_f_aac_count < 200) {
        printf("aacCallback %d %d %f\n", line1, channel, pts);

        fwrite(adts, 1, 7, g_test_f_aac);
        fwrite(buffer, 1, line1, g_test_f_aac);

        g_test_f_aac_count += 1;
    } else {
        fclose(g_test_f_aac);
    }
}

int main() {
    FILE* file = fopen(VIDEO_SOURCE, "rb+");
    //g_test_w_265_f = fopen("./result.h265", "wb");
    g_test_f_yuv = fopen("./result.yuv", "wb");
    g_test_f_hevc = fopen("./result.hevc", "wb");
    g_test_f_pcm = fopen("./result.pcm", "wb");
    g_test_f_aac = fopen("./result.aac", "wb");
    if (file == NULL) {
        printf("open file error\n");
        return -1;
    }

    FILE* file_seek = fopen(VIDEO_SOURCE, "rb+");
    if (!file_seek) return -1;
    fseek(file_seek, 0L, SEEK_END);
    int file_size = ftell(file_seek);
    fclose(file_seek);

    const char *TOKEN_SECRET = "base64:QXV0aG9yOmNoYW5neWFubG9uZ3xudW1iZXJ3b2xmLEdpdGh1YjpodHRwczovL2dpdGh1Yi5jb20vbnVtYmVyd29sZixFbWFpbDpwb3JzY2hlZ3QyM0Bmb3htYWlsLmNvbSxRUTo1MzEzNjU4NzIsSG9tZVBhZ2U6aHR0cDovL3h2aWRlby52aWRlbyxEaXNjb3JkOm51bWJlcndvbGYjODY5NCx3ZWNoYXI6bnVtYmVyd29sZjExLEJlaWppbmcsV29ya0luOkJhaWR1";

    sniffStreamContext = rdIsDad(TOKEN_SECRET);
    if (sniffStreamContext == NULL) {
        return -1;
    }

    initializeModule(
            sniffStreamContext, probeFinCallback,
            frameCallback, naluFrameCallback,
            samplesCallback, aacSamplesCallback);

    uint8_t *buf = (uint8_t *) av_mallocz(sizeof(uint8_t) * BUF_SIZE);
    int n = -1;
    int ret = -1;
    int get_pkt_ret = 0;

    int start_get = 0;

    //uint8_t *testBuf = NULL;
    //int testBufLen = 0;

    while (!feof(file)){
        //n = fread(buf, 1, buf_size, file);
        n = fread(buf, PUSH_UNIT, PUSH_SIZE, file);
        printf("read %d\n", n);

        if (n <= 0) {
            continue;
        }

        ret = pushData(sniffStreamContext, buf, n, (int)((float) file_size / 10));
        //ret = pushData(sniffStreamContext, buf, n, (int)(file_size));
        printf("--------> ret: %d\n", ret);
        if (ret > 0) {
            start_get = 1;
            //break;
        }

        //if (testBuf == NULL) {
        //    testBuf = (uint8_t *) malloc(sizeof(uint8_t) * n);
        //    memcpy(testBuf, buf, n);
        //} else {
        //    uint8_t *dst = reMallocU8(testBuf, testBufLen, buf, n);
        //    free(testBuf);
        //    testBuf = dst;
        //}
        //testBufLen += n;

        if (start_get > 0) {
            get_pkt_ret = getPkg(sniffStreamContext);
            printf("--------> get_pkt_ret: %d\n", get_pkt_ret);
            if (get_pkt_ret == MISSILE_PKT_GET_TYPE_HAVE_VIDEO) {

            }
        }

        /*
        if (g_test_f_yuv_count >= 100) {
            break;
        }
        //if (g_test_f_pcm_count >= 500) {
        //    break;
        //}
        if (g_test_f_aac_count >= 200) {
            break;
        }
        */
    }

    while (1) {
        get_pkt_ret = getPkg(sniffStreamContext);
        printf("--------> get_pkt_ret: %d\n", get_pkt_ret);
        if (get_pkt_ret == MISSILE_PKT_GET_NOTHING) {
            break;
        }
        if (get_pkt_ret < 0) {
            break;
        }
        if (get_pkt_ret == MISSILE_PKT_GET_TYPE_HAVE_VIDEO) {
        }
    }
    //fwrite(testBuf, 1, testBufLen, g_test_w_source_f);

    fclose(g_test_f_hevc);
    fclose(g_test_f_yuv);
    fclose(file);
    sniffStreamContext->releaseFunc(sniffStreamContext);
    return 0;
}


