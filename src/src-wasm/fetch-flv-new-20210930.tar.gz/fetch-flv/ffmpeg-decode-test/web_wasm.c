#include <emscripten.h>
#include <stdio.h>
#include <stdlib.h>

#include "utils/secret.h"
#include "utils/tools.h"

#include "sniff_httpflv.h"

#ifdef __EMSCRIPTEN__
#include <emscripten/fetch.h>
#include <emscripten.h>
#endif


/* **************************************
 *
 *
 *             3.Full Demuxer+Decoder
 *
 *
 * **************************************/
EMSCRIPTEN_KEEPALIVE SniffHTTPFLVContext *AVSniffHttpFlvInit(const char *token, const char* version) {
    if (STRCMP(token, TOKEN_FREE) != 0) {
        printf("t:%s\n", token);
        printf("t:%s\n", TOKEN_SECRET);
        printf("initMissile Sniff Http Flv start FAILED, TOKEN ERROR\n");
        return NULL;
    }
    printf("initMissile Sniff Http Flv start OK\n");

    SniffHTTPFLVContext *sniffHttpFlvContext = newSniffHTTPFLVContext();
    return sniffHttpFlvContext;
}

EMSCRIPTEN_KEEPALIVE int releaseSniffHttpFlv(SniffHTTPFLVContext *sniffHttpFlvContext) {
    int exitRet = releaseSniffHTTPFLVContext(sniffHttpFlvContext);
    printf("VideoMissileHttp exit done:%d\n", exitRet);
    return exitRet;
}


EMSCRIPTEN_KEEPALIVE int initializeSniffHttpFlvModule(
        SniffHTTPFLVContext *sniffHttpFlvContext,
        long (*probeCallback)(void),
        long (*yuvCallback)(void),
        long (*naluCallback)(void),
        long (*pcmCallback)(void),
        long (*aacCallback)(void)
) {
    int initRet = sniffHttpFlvContext->initFunc(sniffHttpFlvContext, MISSILE_SNIFFSTREAM_MODE_LIVE);
    sniffHttpFlvContext->setCodecTypeFunc(
            sniffHttpFlvContext,
            (long) probeCallback, (long) yuvCallback, (long) naluCallback, (long) pcmCallback, (long) aacCallback, 0);
    return initRet;
}

EMSCRIPTEN_KEEPALIVE int initializeSniffHttpFlvModuleWithAOpt(
        SniffHTTPFLVContext *sniffHttpFlvContext,
        long (*probeCallback)(void),
        long (*yuvCallback)(void),
        long (*naluCallback)(void),
        long (*pcmCallback)(void),
        long (*aacCallback)(void),
        int ignoreAudio,
        MISSILE_SNIFFSTREAM_MODE mode
) {
    int initRet = sniffHttpFlvContext->initFunc(sniffHttpFlvContext, mode);
    sniffHttpFlvContext->setCodecTypeFunc(
            sniffHttpFlvContext,
            (long) probeCallback, (long) yuvCallback, (long) naluCallback, (long) pcmCallback, (long) aacCallback,
            ignoreAudio);
    return initRet;
}

EMSCRIPTEN_KEEPALIVE int pushSniffHttpFlvData(
        SniffHTTPFLVContext *sniffHttpFlvContext, uint8_t *buff, int in_len, int probe_size) {
    int pushRet = sniffHttpFlvContext->pushBufferFunc(sniffHttpFlvContext, buff, in_len, probe_size);
    return pushRet;
}

// getBufferLength
EMSCRIPTEN_KEEPALIVE int getBufferLengthApi(SniffHTTPFLVContext *sniffHttpFlvContext)
{
    int getRet = sniffHttpFlvContext->getBufferLength(sniffHttpFlvContext);
    return getRet;
}

EMSCRIPTEN_KEEPALIVE int getSniffHttpFlvPkg(SniffHTTPFLVContext *sniffHttpFlvContext) {
    int getRet = sniffHttpFlvContext->getPacketFunc(sniffHttpFlvContext, 1);
    return getRet;
}

EMSCRIPTEN_KEEPALIVE int getSniffHttpFlvPkgNoCheckProbe(SniffHTTPFLVContext *sniffHttpFlvContext) {
    int getRet = sniffHttpFlvContext->getPacketFunc(sniffHttpFlvContext, 0);
    return getRet;
}

EMSCRIPTEN_KEEPALIVE int decodeHttpFlvVideoFrame(
        SniffHTTPFLVContext *sniffHttpFlvContext,
        uint8_t *buff, int len, long pts, long dts, int tag) {
    //printf("debug +++ EMSCRIPTEN_KEEPALIVE decodeVideoFrame pts:%d\n", pts);
    int decRet = sniffHttpFlvContext->decodeVideoFrameFunc(
            sniffHttpFlvContext, buff, len, pts, dts, tag);
    return decRet;
}

int main() {
    printf("wasm httpflv main\n");
    EM_ASM(
        if (typeof window!="undefined") {
            window.dispatchEvent(new CustomEvent("wasmHttpFLVLoaded"))
        } else {
            global.onWASMLoaded && global.onWASMLoaded()
        }
    );
    return EXIT_SUCCESS;
}


