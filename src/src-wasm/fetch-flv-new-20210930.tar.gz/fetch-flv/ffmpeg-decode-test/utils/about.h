#include <stdio.h>
#include <string.h>

void introduce_mine();

