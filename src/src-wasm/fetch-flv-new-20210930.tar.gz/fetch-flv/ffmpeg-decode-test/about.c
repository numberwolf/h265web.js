#include "about.h"

#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>
#include <stdlib.h>

#ifdef __EMSCRIPTEN__
#include <emscripten/fetch.h>
#include <emscripten.h>
#endif

#define MAXLINE 500

//void downloadSucceeded(emscripten_fetch_t *fetch) {
//    printf("Finished downloading %llu bytes from URL %s.\n", fetch->numBytes, fetch->url);
//    // The data is now available at fetch->data[0] through fetch->data[fetch->numBytes-1];
//    for (size_t i = 0; i < fetch->numBytes; ++i) {
//        printf("%c", fetch->data[i]);
//    }
//    printf("\n");
//
//    emscripten_fetch_close(fetch); // Free data associated with the fetch.
//}
//
//void downloadFailed(emscripten_fetch_t *fetch) {
//    printf("Downloading %s failed, HTTP failure status code: %d.\n", fetch->url, fetch->status);
//    emscripten_fetch_close(fetch); // Also free data on failure.
//}
//
//int testRequest() {
//    emscripten_fetch_attr_t attr;
//    emscripten_fetch_attr_init(&attr);
//    strcpy(attr.requestMethod, "GET");
//    attr.attributes = EMSCRIPTEN_FETCH_LOAD_TO_MEMORY;
//    attr.onsuccess = downloadSucceeded;
//    attr.onerror = downloadFailed;
//    emscripten_fetch(&attr, "http://apih265webjs.yuveye.com/?c=domainLimit&a=check&t=123124214124");
//
//    printf("[testRequest] all ok now\n");
//    return 0;
//}

void introduce_mine() {
    //testRequest();
	printf("/********************************************************* \n");
    printf("* \n");
    printf("* Author: %s\n",    "Numberwolf - ChangYanlong");
    printf("* QQ: %s\n",        "531365872");
    printf("* Discord: %s\n",   "numberwolf#8694");
    printf("* E-Mail: %s\n",    "porschegt23@foxmail.com");
    printf("* Github: %s\n",    "https://github.com/numberwolf/h265web.js");
    printf("* \n");
	printf("* 作者: %s\n",       "小老虎(Numberwolf)(常炎隆)");
	printf("* QQ: %s\n",		"531365872");
    printf("* Discord: %s\n",   "numberwolf#8694");
	printf("* 邮箱: %s\n",       "porschegt23@foxmail.com");
	printf("* 博客: %s\n",       "https://www.jianshu.com/u/9c09c1e00fd1");
    printf("* Github: %s\n",    "https://github.com/numberwolf/h265web.js");
    printf("* \n");
	printf("**********************************************************/\n");
}

