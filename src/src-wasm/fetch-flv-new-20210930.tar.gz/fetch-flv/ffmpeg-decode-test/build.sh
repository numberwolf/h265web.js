#!/bin/bash
# Author: changyanlong01
# Created Time: 三  7/28 18:54:22 2021
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib
export LIBRARY_PATH=$LIBRARY_PATH:/usr/local/lib

cd output
cmake ..
make
