#!/bin/bash
# Author: changyanlong01
# Created Time: 二 10/20 11:21:38 2020

#REMOVE_FUNCS="console.log"
REMOVE_FUNCS=""

#
# 打包源码
#
REMOVE_FUNCS=""
browserify -e ./play.js -o ./dist/dist-tmp.js
terser ./dist/dist-tmp.js -c pure_funcs=[${REMOVE_FUNCS}],toplevel=true -m -o ./dist/dist.js





