onmessage = (event) => {

    // console.log("parse - worker.onmessage", event);
    let body = event.data;
    let cmd = null;
    if (body.cmd === undefined || body.cmd === null) {
    	cmd = '';
    } else {
    	cmd = body.cmd;
    }

    // console.log("parse - worker recv cmd:", cmd);

    switch (cmd) {
        case 'append-chunk':
        	console.log("parse - worker append-chunk");
            /*
        	let chunk = body.data;
            let ptr = body.ptr;
            let Module = body.Module;

            let offset_video = Module._malloc(chunk.length);
            Module.HEAP8.set(chunk, offset_video);

            Module.cwrap("pushSniffStreamData", "number", ["number", "number", "number", "number"])(
                ptr, offset_video, chunk.length, 512 * 100
            );

            Module._free(offset_video);
            offset_video = null;
            */

            break;
        case 'get-nalu':
            // let nalBuf = g_RawParser.nextNalu();
            //let nalBuf = g_RawParser.nextFrame();
            // console.log("parse - worker get-nalu", nalBuf);


            postMessage({
                cmd : "return-nalu",
                data : '',
                msg : "return-nalu"
            });
            // if (nalBuf != false) {
                /*postMessage({
                    cmd : "return-nalu",
                    data : nalBuf,
                    msg : "return-nalu"
                });*/
            // }

            break;
        case 'stop':
        	// console.log("parse - worker stop");
            postMessage('parse - WORKER STOPPED: ' + body);
           	close(); // Terminates the worker.
            break;
        default:
        	// console.log("parse - worker default");
        	// console.log("parse - worker.body -> default: ", body);
            // worker.postMessage('Unknown command: ' + data.msg);
            break;
    };
}; // onmessage
