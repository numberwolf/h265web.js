// @TODO LIVE
const def = require('./consts');
const RenderEngine420P = require('./webgl420');

// mem
const AU_FMT_READ                       = 10;
const MISSILE_PKT_GET_TYPE_AAC          = 100;
const MISSILE_PKT_GET_TYPE_HAVE_VIDEO   = 200;
const MISSILE_PKT_GET_TYPE_YUV          = 300;
const MISSILE_PKT_GET_NOTHING           = 404;
const MISSILE_PKT_GET_SPLIT_FINISHED    = 405;

const READY_PUSH_COUNT_LIMIT            = 0;

function getScriptPath(foo) { return window.URL.createObjectURL(new Blob([foo.toString().match(/^\s*function\s*\(\s*\)\s*\{(([\s\S](?!\}$))*[\s\S])/)[1]], { type: 'text/javascript' })); }

export default class CHttpLiveCoreModule {
	constructor(config) {
		this.config = {
			width: config.width || def.DEFAULT_WIDTH,
            height: config.height || def.DEFAULT_HEIGHT,
            fps: config.fps || def.DEFAULT_FPS,
            sampleRate: config.sampleRate || def.DEFAULT_SAMPLERATE,
            playerId: config.playerId || def.DEFAILT_WEBGL_PLAY_ID,
            token: config.token || null,
            probeSize: config.probeSize || 4096,
        }; // end this.config

        this.AVSniffPtr = null;
        this.AVGetInterval = null;
        this.AVDecodeInterval = null;

        this.ready_now = 0;
        this.cache_status = 1;
        this.download_length = 0;

        this.AVGLObj = null;
        this.CanvasObj = document.querySelector("#canvas");
        this.NaluBuf = [];
        this.YuvBuf = [];

        // fetch worker
        let _this = this;
        // console.warn("_this before AVSniffPtr:", _this);
        this.workerFetch = new Worker('./worker-fetch.js');
        this.workerFetch.onmessage = function(event) {
            _this._workerFetch_onmessage(event, _this);
        };

        this.totalLen = 0;
        this.pushPkg = 0;

    } // end func constructor

    _workerFetch_onmessage(event, _this) {
        // console.log("play -> workerFetch recv:", event, playerObj);
        let body = event.data;
        let cmd = null;
        if (body.cmd === undefined || body.cmd === null) {
            cmd = '';
        } else {
            cmd = body.cmd;
        }
        // console.log("play -> workerFetch recv cmd:", cmd);
        switch (cmd) {
            case 'fetch-chunk':
                //console.log("play -> workerFetch append chunk");
                let chunk = body.data;
                _this.download_length += chunk.length;

                let push_ret = 0;
                setTimeout(function() {
                    let offset_video = Module._malloc(chunk.length);
                    Module.HEAP8.set(chunk, offset_video);

                    // console.warn("_this.AVSniffPtr:", _this);
                    push_ret = Module.cwrap("pushSniffHttpFlvData", "number", ["number", "number", "number", "number"])(
                        _this.AVSniffPtr, offset_video, chunk.length, 4096
                    );
                    // console.warn("pushRet:", push_ret);

                    Module._free(offset_video);
                    offset_video = null;
                }, 0); // end setTimeout

                _this.totalLen += chunk.length;
                //console.log("play -> workerFetch append chunk ret: ", push_ret, chunk.length, totalLen);
                _this.pushPkg++;

                // /*
                if (_this.AVGetInterval === undefined 
                    || _this.AVGetInterval === null) 
                {
                    _this.AVGetInterval = window.setInterval(function() {
                        let bufLen = Module.cwrap("getBufferLengthApi", "number", ["number"])(_this.AVSniffPtr);
                        console.log("play -> workerFetch last buf len: ", bufLen);
                        if (bufLen > _this.config.probeSize) {
                        // if (pushPkg > READY_PUSH_COUNT_LIMIT) {
                            let get_ret = Module.cwrap("getSniffHttpFlvPkg", "number", ["number"])(_this.AVSniffPtr);
                            console.log("play -> workerFetch get nalu ret: ", get_ret, _this.pushPkg);
                            _this.pushPkg -= 1;
                            _this.ready_now = 1;
                        // }
                        } // end if buf len check
                    }, 5);
                } // end if AVGetInterval
                break;
            case 'fetch-fin':
                // fetchFinished = true;
                /*
                if (AVGetInterval !== undefined || AVGetInterval !== null) {
                    console.log(" OVER========================>", AVGetInterval);
                    window.clearInterval(AVGetInterval);
                    AVGetInterval = null;
                }
                */
                break;
            default:
                break;
        } // end switch
    } // end function _workerFetch_onmessage

    // callback
    _callbackProbe(duration, width, height, fps,
        audioIdx,
        sample_rate, channels, vcodec_name_id, sample_fmt) 
    {
        const hex = Module.HEAPU8.subarray(sample_fmt, sample_fmt + AU_FMT_READ);
        let sample_fmt_str = "";
        for (let i = 0; i < hex.length; i++) {
            let char = String.fromCharCode(hex[i]);
            sample_fmt_str += char;
        }
        console.log("callbackProbe", duration, width, height, fps,
            audioIdx,
            sample_rate, channels, vcodec_name_id, sample_fmt_str);
    } // end func _callbackProbe

    _callbackYUV(y, u, v, line_y, line_u, line_v, w, h, pts) 
    {
        console.log("callbackYUV==============>", line_y, line_u, line_v, w, h, pts);

        let offsetY = Module.HEAPU8.subarray(y, y + line_y * h);
        let bufY = new Uint8Array(offsetY);

        let offsetU = Module.HEAPU8.subarray(u, u + line_u * h / 2);
        let bufU = new Uint8Array(offsetU);

        let offsetV = Module.HEAPU8.subarray(v, v + line_v * h / 2);
        let bufV = new Uint8Array(offsetV);

        let data = {
            //AVGLObj: AVGLObj,
            bufY: bufY,
            bufU: bufU,
            bufV: bufV,
            line_y: line_y,
            h: h,
            pts: pts,
        };

        this.YuvBuf.push(data);

        if (this.cache_status > 0 && this.YuvBuf.length > 50) {
            console.log("YUV cache finished");
            this.cache_status = 0;
        }

        //renderFrame(AVGLObj, bufY, bufU, bufV, line_y, h);
        /*
        workerGL.postMessage({
            cmd: "start", 
            data: {
                AVGLObj: AVGLObj,
                bufY: bufY,
                bufU: bufU,
                bufV: bufV,
                line_y: line_y,
                h: h
            },
            msg: "start"
        });*/

        Module._free(offsetY);
        offsetY = null;
        Module._free(offsetU);
        offsetU = null;
        Module._free(offsetV);
        offsetV = null;

        //bufY = null;
        //bufU = null;
        //bufV = null;
    } // end func _callbackYUV

    _callbackNALU(data, len, isKey, w, h, pts, dts) 
    {
        //return;
        console.log("callbackNALU len", len);
        console.log("callbackNALU is key", isKey);
        console.log("callbackNALU w h", w, h);
        console.log("callbackNALU time HEVC dts", dts);

        let offsetFrame = Module.HEAPU8.subarray(data, data + len);
        let bufData = new Uint8Array(offsetFrame);
        //console.log("callbackNALU Data:", bufData);
        this.NaluBuf.push({
            bufData: bufData,
            len: len,
            isKey: isKey,
            w: w,
            h: h,
            pts: pts * 1000,
            dts: dts * 1000
        }); 

        /*
        let offset_video = Module._malloc(bufData.length);
        Module.HEAP8.set(bufData, offset_video);

        // decode start
        let decRet = Module.cwrap("decodeVideoFrame", "number", 
            ["number", "number", "number", "number", "number"])
            (AVSniffPtr, offset_video, bufData.length, pts, dts, 0);
        console.log("decodeVideoFrame ret:", decRet); 
        // decode end

        */
        //bufData = null;
        Module._free(offsetFrame);
        offsetFrame = null;
        //Module._free(offset_video);
        //offset_video = null;
    } // end func _callbackNALU

    _callbackPCM(pcm) {
    } // end func _callbackPCM

    _callbackAAC(adts, buffer, line1, channel, pts) {
        console.log("callbackNALU time AAC dts", pts);
    } // end func _callbackPCM

    _decode() {
        let _this = this;
        if (this.AVDecodeInterval === undefined 
            || this.AVDecodeInterval === null) 
        {
            this.AVDecodeInterval = setInterval(function() {
                let item = _this.NaluBuf.shift();
                if (item !== undefined && item !== null) {

                    let offset_video = Module._malloc(item.bufData.length);
                    Module.HEAP8.set(item.bufData, offset_video);

                    // decode start
                    let decRet = Module.cwrap("decodeHttpFlvVideoFrame", "number",
                        ["number", "number", "number", "number", "number"])
                        (_this.AVSniffPtr, offset_video, item.bufData.length, item.pts, item.dts, 0);
                    //console.log("decodeVideoFrame ret:", decRet); 
                    // decode end

                    //item.bufData = null;
                    Module._free(offset_video);
                    offset_video = null;
                }
            }, 1); // end this.AVDecodeInterval
        } // decode
    } // end func _decode

    play() {
        let _this = this;
        // if (this.ready_now > 0) {
            let playInterval = setInterval(function() {
                // console.log("YUV cachestatus", _this.cache_status);
                if (_this.cache_status <= 0) {
                    let item = _this.YuvBuf.shift(); 
                    console.log("YUV pts", item.pts);
                    if (item != undefined && item !== null) {
                        RenderEngine420P.renderFrame(_this.AVGLObj, item.bufY, item.bufU, item.bufV, item.line_y, item.h);
                    }
                    if (_this.YuvBuf.length <= 1) {
                        console.log("YUV cacheing");
                        _this.cache_status = 1;
                    }
                }
            }, 1000 / 35);
        // }
    } // end func play

    start(url265) {
        const TOKEN_SECRET = "base64:QXV0aG9yOmNoYW5neWFubG9uZ3xudW1iZXJ3b2xmLEdpdGh1YjpodHRwczovL2dpdGh1Yi5jb20vbnVtYmVyd29sZixFbWFpbDpwb3JzY2hlZ3QyM0Bmb3htYWlsLmNvbSxRUTo1MzEzNjU4NzIsSG9tZVBhZ2U6aHR0cDovL3h2aWRlby52aWRlbyxEaXNjb3JkOm51bWJlcndvbGYjODY5NCx3ZWNoYXI6bnVtYmVyd29sZjExLEJlaWppbmcsV29ya0luOkJhaWR1";

        this.AVSniffPtr = Module.cwrap("AVSniffHttpFlvInit", "number", ["string", "string"])(
            TOKEN_SECRET, '0.0.0'
        );
        console.log("wasmHttpFLVLoaded!!", this.AVSniffPtr);

        console.log("start add function probeCallback");
        let probeCallback   = Module.addFunction(this._callbackProbe.bind(this));

        console.log("start add function yuvCallback");
        let yuvCallback     = Module.addFunction(this._callbackYUV.bind(this));

        console.log("start add function naluCallback");
        let naluCallback    = Module.addFunction(this._callbackNALU.bind(this));

        console.log("start add function sampleCallback");
        let sampleCallback  = Module.addFunction(this._callbackPCM.bind(this));

        console.log("start add function aacCallback");
        let aacCallback     = Module.addFunction(this._callbackAAC.bind(this)); 

        let callbackRet = Module.cwrap(
            "initializeSniffHttpFlvModule",
            "number",
            ["number", "number", "number", "number", "number", "number"])
            (this.AVSniffPtr, 
                probeCallback, yuvCallback, naluCallback, sampleCallback, aacCallback);
        console.log("create_media_processor callbackRet: ", callbackRet);

        this.AVGLObj = RenderEngine420P.setupCanvas(this.CanvasObj, {preserveDrawingBuffer: false})

        // var url265 = "https://ahekv0bx0fsc5jjda5z.down.evs.bcelive.com/evs/hsnFWkELtOSv.flv?timestamp=1632799645&token=412ca3ab22886dd6faac3a405ed69de265abdb86afae91cf1861d78d05cd61e7";
        this.workerFetch.postMessage({cmd: "start", data: url265, msg: "start"});
        this._decode();
        this.play();
    } // end func startPost


} // end class CHttpLiveCoreModule

// exports.CHttpLiveCore = CHttpLiveCoreModule;
