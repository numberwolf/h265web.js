console.log("import gl worker!!!");

//var CanvasObj = document.querySelector("#canvas");
//var AVGLObj = setupCanvas(CanvasObj, {preserveDrawingBuffer: false})

onmessage = (event) => {

    // console.log("worker.onmessage", event);
    let body = event.data;
    let cmd = null;
    if (body.cmd === undefined || body.cmd === null) {
    	cmd = '';
    } else {
    	cmd = body.cmd;
    }

    // console.log("worker recv cmd:", cmd);
    switch (cmd) {
        case 'callyuv':
            if (CanvasObj.width != body.line_y || CanvasObj.height != body.h) {
                CanvasObj.width = body.line_y;
                CanvasObj.height = body.h;
            }

            renderFrame(body.AVGLObj, body.bufY, body.bufU, body.bufV, body.line_y, body.h); 
            break;
        default:
        	// console.log("worker default");
        	// console.log("worker.body -> default: ", body);
            // worker.postMessage('Unknown command: ' + data.msg);
            break;
    };
};
